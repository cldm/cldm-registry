API
---

Djula external symbols documentation

.. cl:package:: djula

.. cl:function:: compile-template*



.. cl:function:: url-encode

.. cl:variable:: *current-store*

.. cl:variable:: *allow-include-roots*

.. cl:variable:: *current-compiler*



.. cl:variable:: *fancy-debug-p*

.. cl:variable:: *djula-execute-package*

.. cl:function:: fetch-template*

.. cl:function:: url-encode-path

.. cl:function:: url-decode

.. cl:macro:: def-tag-compiler





.. cl:function:: find-template*

.. cl:variable:: *fancy-error-template-p*



.. cl:variable:: *default-language*



.. cl:function:: render-template*

.. cl:function:: add-template-directory

.. cl:variable:: *catch-template-errors-p*

.. cl:variable:: *current-language*

.. cl:variable:: *verbose-errors-p*



